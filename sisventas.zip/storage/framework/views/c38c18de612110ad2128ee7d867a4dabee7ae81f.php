<!DOCTYPE>
<html>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte de Ingreso</title>
    <style>
        body {
        /*position: relative;*/
        /*width: 16cm;  */
        /*height: 29.7cm; */
        /*margin: 0 auto; */
        /*color: #555555;*/
        /*background: #FFFFFF; */
        font-family: Arial, sans-serif; 
        font-size: 14px;
        /*font-family: SourceSansPro;*/
        }

        #logo{
        float: left;
        margin-top: 1%;
        margin-left: 2%;
        margin-right: 2%;
        }

        #imagen{
        width: 150px;
        }

        #datos{
        float: left;
        margin-top: 0%;
        margin-left: 2%;
        margin-right: 2%;
        /*text-align: justify;*/
        }

        #encabezado{
        text-align: center;        
        margin-right: 50%;
        font-size: 15px;
        }

        #fact{
        /*position: relative;*/
        float: right;        
        margin-left: 2%;
        margin-right: 2%;
        font-size: 15px;
        }

        section{
        clear: left;
        }

        #cliente{
        text-align: left;
        }

        #facliente{
        width: 40%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-top: 15px;
        }

        #fac, #fv, #fa{
        color: #FFFFFF;
        font-size: 15px;
        }

        #facliente thead{
        padding: 20px;
        background: #E67E07;
        text-align: left;
        border-bottom: 1px solid #FFFFFF;  
        }

        #facvendedor{
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #facvendedor thead{
        padding: 20px;
        background: #E67E07;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;  
        }

        #facarticulo{
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #facarticulo thead{
        padding: 20px;
        background: #E67E07;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;  
        }

        #gracias{
        text-align: center; 
        }
    </style>
    <body>
        <?php $__currentLoopData = $ingreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <header><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <div id="logo">
                <img src="<?php echo e(base_path()); ?>/img/logo.png" alt="logo" id="imagen">
            </div>
            <div id="datos">
                <div id="encabezado">
                    <b>GRUPO CARDEÑA S.A.C.</b><br>
                    Francisco Bolognesi Nº 712 Chivay-Arequipa<br>
                    Telefono: (+51) 962985509<br>
                    Email: rafael.cr@grupocarden.com
                </div>
            </div>
            <div id="fact" align="center">
                <b>          
                    R.U.C. 20539375866<br>
                    <?php echo e($i->tipo_comprobante); ?><br>
                    <?php echo e($i->serie_comprobante); ?>-<?php echo e($i->num_comprobante); ?>                
                </b>
            </div>
        </header>
        <br>
        <section>
            <div>
                <table id="facliente">
                    <thead>                        
                        <tr>
                            <th id="fac">Proveedor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <p id="cliente">
                                    <b>Sr(a). <?php echo e($i->nombre); ?></b><br>
                                    <?php if($i->num_documento != ''): ?>
                                        <b><?php echo e($i->tipo_documento); ?>:</b> <?php echo e($i->num_documento); ?><br>
                                    <?php endif; ?>
                                    <?php if($i->direccion != ''): ?>
                                        <b>Dirección:</b> <?php echo e($i->direccion); ?><br>
                                    <?php endif; ?>
                                    <?php if($i->telefono != ''): ?>
                                        <b>Teléfono:</b> <?php echo e($i->telefono); ?><br>
                                    <?php endif; ?>
                                    <?php if($i->email != ''): ?>
                                        <b>Email:</b> <?php echo e($i->email); ?>

                                    <?php endif; ?>
                                </</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <section>
            <div>
                <table id="facvendedor">
                    <thead>
                        <tr id="fv">
                            <th>ALMACENERO</th>
                            <th>FECHA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td align="center"><?php echo e($i->usuario); ?></td>
                            <td align="center"><?php echo e(date('d-m-Y', strtotime($i->fecha_hora))); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <br>
        <section>
            <div>
                <table id="facarticulo">
                    <thead>
                        <tr id="fa">
                            <th>CANT</th>
                            <th>DESCRIPCION</th>
                            <th>PRECIO UNIT</th>
                            <th>IMPORTE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="center"><?php echo e($det->cantidad); ?></td>
                            <td><?php echo e($det->articulo); ?></td>
                            <td align="center"><?php echo e($det->precio); ?></td>
                            <td align="right"><?php echo e(number_format($det->cantidad*$det->precio,2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <?php $__currentLoopData = $ingreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th></th>
                            <th></th>
                            <th align="right">SUBTOTAL</th>
                            <td align="right">S/. <?php echo e(number_format($i->total-($i->total*$i->impuesto),2)); ?></td>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th align="right">I.G.V. (<?php echo e($i->impuesto*100); ?>%)</th>
                            <td align="right">S/. <?php echo e(number_format($i->total*$i->impuesto,2)); ?></td>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th align="right">TOTAL</th>
                            <td align="right">S/. <?php echo e($i->total,2); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tfoot>
                </table>
            </div>
        </section>
        <br>
        <br>
        <footer>
            <div id="gracias">
                <p><b>Este comprobante de ingreso almacén ha sido generado por el sistema, no es un comprobante emitido por el proveedor.</b></p>
            </div>
        </footer>
    </body>
</html><?php /**PATH F:\project_warehouse\carden-web\sisventas\resources\views/pdf/ingreso.blade.php ENDPATH**/ ?>