<!DOCTYPE>
<html>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte de Servicio</title>
    <style>
        body {
        /*position: relative;*/
        /*width: 16cm;  */
        /*height: 29.7cm; */
        /*margin: 0 auto; */
        /*color: #555555;*/
        /*background: #FFFFFF; */
        font-family: Arial, sans-serif; 
        font-size: 14px;
        /*font-family: SourceSansPro;*/
        }

        #logo{
        float: left;
        margin-top: 1%;
        margin-left: 2%;
        margin-right: 2%;
        }

        #imagen{
        width: 150px;
        }

        #datos{
        float: left;
        margin-top: 0%;
        margin-left: 2%;
        margin-right: 2%;
        /*text-align: justify;*/
        }

        #encabezado{
        text-align: center;        
        margin-right: 50%;
        font-size: 15px;
        }

        #fact{
        /*position: relative;*/
        float: right;        
        margin-left: 2%;
        margin-right: 2%;
        font-size: 15px;
        }

        section{
        clear: left;
        }

        #cliente{
        text-align: left;        
        }

        #facliente{
        width: 40%;
        border-collapse: collapse;
        border-spacing: 0;        
        margin-top: 15px;
        }

        #fac, #fv, #fa{
        color: #FFFFFF;
        font-size: 15px;
        }

        #facliente thead{
        padding: 20px;
        background: #2183E3;
        text-align: left;
        border-bottom: 1px solid #FFFFFF;  
        }

        #facvendedor{
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #facvendedor thead{
        padding: 20px;
        background: #2183E3;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;  
        }

        #facarticulo{
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #facarticulo thead{
        padding: 20px;
        background: #2183E3;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;  
        }

        #gracias{
        text-align: center; 
        }
    </style>
    <body>
        <?php $__currentLoopData = $servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <header>
            <div id="logo">
                <img src="<?php echo e(base_path()); ?>/public/img/logo.png" alt="incanatoIT" id="imagen">
            </div>
            <div id="datos">
                <div id="encabezado">
                    <b>GRUPO CARDEÑA S.A.C.</b><br>
                    Francisco Bolognesi Nº 712 Chivay-Arequipa<br>
                    Teléfono: (+51) 962985509<br>
                    Email: rafael.cr@grupocarden.com
                </div>
            </div>
            <div id="fact" align="center">      
                <b>          
                    R.U.C. 20539375866<br>
                    <?php echo e($s->tipo_comprobante); ?><br>
                    <?php echo e($s->serie_comprobante); ?>-<?php echo e($s->num_comprobante); ?>                
                </b>
            </div>
        </header>        
        <section>
            <div>
                <table id="facliente">
                    <thead>                        
                        <tr>
                            <th id="fac">Cliente</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <p id="cliente">
                                    <b>Sr(a). <?php echo e($s->nombre); ?></b><br>
                                    <?php if($s->num_documento != ''): ?>
                                        <b><?php echo e($s->tipo_documento); ?>:</b> <?php echo e($s->num_documento); ?><br>
                                    <?php endif; ?>
                                    <?php if($s->direccion != ''): ?>
                                        <b>Dirección:</b> <?php echo e($s->direccion); ?><br>
                                    <?php endif; ?>
                                    <?php if($s->telefono != ''): ?>
                                        <b>Teléfono:</b> <?php echo e($s->telefono); ?><br>
                                    <?php endif; ?>
                                    <?php if($s->email != ''): ?>
                                        <b>Email:</b> <?php echo e($s->email); ?>

                                    <?php endif; ?>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <section>
            <div>
                <table id="facvendedor">
                    <thead>
                        <tr id="fv">
                            <th>VENDEDOR</th>
                            <th>FECHA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td align="center"><?php echo e($s->usuario); ?></td>
                            <td align="center"><?php echo e(date('d-m-Y', strtotime($s->fecha_hora))); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <br>
        <section>
            <div>
                <table id="facarticulo">
                    <thead>
                        <tr id="fa">
                            <th>CANT</th>
                            <th>DESCRIPCION</th>
                            <th>PRECIO UNIT</th>
                            <th>DESC.</th>
                            <th>IMPORTE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td align="center"><?php echo e($det->cantidad); ?></td>
                            <td><?php echo e($det->descripcion); ?></td>
                            <td align="center"><?php echo e($det->precio); ?></td>
                            <td align="center"><?php echo e($det->descuento); ?></td>
                            <td align="right"><?php echo e(number_format($det->cantidad*$det->precio-$det->descuento, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <?php $__currentLoopData = $servicio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th align="right">SUBTOTAL</th>
                            <td align="right">S/. <?php echo e(number_format($s->total-($s->total*$s->impuesto), 2)); ?></td>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th align="right">I.G.V. (<?php echo e($s->impuesto*100); ?>%)</th>
                            <td align="right">S/. <?php echo e(number_format($s->total*$s->impuesto, 2)); ?></td>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th align="right">TOTAL</th>
                            <td align="right">S/. <?php echo e($s->total); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tfoot>
                </table>
            </div>
        </section>
        <br>
        <br>
        <footer>
            <div id="gracias">
                <p><b>Gracias por solicitar nuestros servicios!</b></p>
            </div>
        </footer>
    </body>
</html><?php /**PATH F:\project_warehouse\carden-web\sisventas75\resources\views/pdf/servicio.blade.php ENDPATH**/ ?>