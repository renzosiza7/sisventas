<footer class="app-footer my-footer">
    <span><a href="http://www.rs7.app/" target="_blank">RS7-APPS</a> &copy; 2019</span>
    <span class="ml-auto">Desarrollado por 
        <a href="http://www.facebook.com/rs7apps" target="_blank">www.rs7.app</a>
    </span>
</footer><?php /**PATH /home/grupocar/public_html/sisventas/resources/views/footer.blade.php ENDPATH**/ ?>