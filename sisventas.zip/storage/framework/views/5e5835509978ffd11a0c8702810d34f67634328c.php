<footer class="app-footer my-footer">

    <span><a href="#" target="_blank">SISTEMA DE VENTAS Y FACTURACIÓN</a> &copy; 2021</span>

    <span class="ml-auto">Desarrollado por 

        <a href="https://www.facebook.com/SYSCAR.AQP" target="_blank">Software y consultoría RDC Perú</a>

    </span>

</footer><?php /**PATH F:\project_warehouse\carden-web\sisventas\resources\views/footer.blade.php ENDPATH**/ ?>