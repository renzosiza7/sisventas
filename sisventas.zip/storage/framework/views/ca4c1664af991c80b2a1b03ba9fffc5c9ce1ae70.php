<?php $__env->startSection('contenido'); ?>
<template v-if="menu == 0">
    <articulo-component :key="renderKey" :ruta="ruta"/>    
</template>
<template v-if="menu == 'categorias'">
    <categoria-component :key="renderKey" :ruta="ruta"/>
</template>
<template v-if="menu == 'marcas'">
    <marca-component :key="renderKey" :ruta="ruta"/>
</template>
<template v-if="menu == 'articulos'">
    <articulo-component :key="renderKey" :ruta="ruta"/>
</template>
<template v-if="menu == 'clientes'">
    <cliente-component :key="renderKey" :ruta="ruta"/>
</template>
<template v-if="menu == 'proveedores'">
    <proveedor-component :key="renderKey" :ruta="ruta"/>
</template>
<template v-if="menu == 'roles'">
    <rol-component :key="renderKey" :ruta="ruta"/>
</template>
<template v-if="menu == 'usuarios'">
    <usuario-component :key="renderKey" :ruta="ruta"/>
</template>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project_warehouse\sisventas\resources\views/contenido.blade.php ENDPATH**/ ?>