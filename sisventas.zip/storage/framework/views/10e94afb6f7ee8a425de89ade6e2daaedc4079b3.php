<!DOCTYPE>
<html>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reporte de Ingreso</title>
    <style>
        body {
        /*position: relative;*/
        /*width: 16cm;  */
        /*height: 29.7cm; */
        /*margin: 0 auto; */
        /*color: #555555;*/
        /*background: #FFFFFF; */
        font-family: Arial, sans-serif; 
        font-size: 14px;
        /*font-family: SourceSansPro;*/
        }

        #logo{
        float: left;
        margin-top: 1%;
        margin-left: 2%;
        margin-right: 2%;
        }

        #imagen{
        width: 150px;
        }

        #datos{
        float: left;
        margin-top: 0%;
        margin-left: 2%;
        margin-right: 2%;
        /*text-align: justify;*/
        }

        #encabezado{
        text-align: center;
        margin-left: 10%;
        margin-right: 35%;
        font-size: 15px;
        }

        #fact{
        /*position: relative;*/
        float: right;
        margin-top: 2%;
        margin-left: 2%;
        margin-right: 2%;
        font-size: 20px;
        }

        section{
        clear: left;
        }

        #cliente{
        text-align: left;
        }

        #facliente{
        width: 40%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #fac, #fv, #fa{
        color: #FFFFFF;
        font-size: 15px;
        }

        #facliente thead{
        padding: 20px;
        background: #E67E07;
        text-align: left;
        border-bottom: 1px solid #FFFFFF;  
        }

        #facvendedor{
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #facvendedor thead{
        padding: 20px;
        background: #E67E07;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;  
        }

        #facarticulo{
        width: 100%;
        border-collapse: collapse;
        border-spacing: 0;
        margin-bottom: 15px;
        }

        #facarticulo thead{
        padding: 20px;
        background: #E67E07;
        text-align: center;
        border-bottom: 1px solid #FFFFFF;  
        }

        #gracias{
        text-align: center; 
        }
    </style>
    <body>
        <?php $__currentLoopData = $ingreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <header>
        <div id="logo">
                <img src="<?php echo e(base_path()); ?>/public/img/logo.png" alt="incanatoIT" id="imagen">
            </div>
            <div id="datos">
                <p id="encabezado">
                <b>GRUPO CARDEÑA S.A.C.</b><br>Francisco Bolognesi Nº 712 Chivay-Arequipa<br>Telefono:(+51) 962985509<br>Email:rafael.cr@grupocarden.com
                </p>
            </div>
            <div id="fact">
                <p><?php echo e($i->tipo_comprobante); ?><br>
                <?php echo e($i->serie_comprobante); ?>-<?php echo e($i->num_comprobante); ?></p>
            </div>
        </header>
        <br>
        <section>
            <div>
                <table id="facliente">
                    <thead>                        
                        <tr>
                            <th id="fac">Proveedor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th><p id="cliente">Sr(a). <?php echo e($i->nombre); ?><br>
                            <?php echo e($i->tipo_documento); ?>: <?php echo e($i->num_documento); ?><br>
                            Dirección: <?php echo e($i->direccion); ?><br>
                            Teléfono: <?php echo e($i->telefono); ?><br>
                            Email: <?php echo e($i->email); ?></</p></th>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <section>
            <div>
                <table id="facvendedor">
                    <thead>
                        <tr id="fv">
                            <th>ALMACENERO</th>
                            <th>FECHA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($i->usuario); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($i->fecha_hora))); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <br>
        <section>
            <div>
                <table id="facarticulo">
                    <thead>
                        <tr id="fa">
                            <th>CANT</th>
                            <th>DESCRIPCION</th>
                            <th>PRECIO UNIT</th>
                            <th>PRECIO TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($det->cantidad); ?></td>
                            <td><?php echo e($det->articulo); ?></td>
                            <td><?php echo e($det->precio); ?></td>
                            <td><?php echo e($det->cantidad*$det->precio); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <?php $__currentLoopData = $ingreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>SUBTOTAL</th>
                            <td>S/. <?php echo e($i->total-($i->total*$i->impuesto)); ?></td>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>Impuesto</th>
                            <td>S/. <?php echo e($i->total*$i->impuesto); ?></td>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th>TOTAL</th>
                            <td>S/. <?php echo e($i->total,2); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tfoot>
                </table>
            </div>
        </section>
        <br>
        <br>
        <footer>
            <div id="gracias">
                <p><b>Este comprobante de ingreso almacén ha sido generado por el sistema, no es un comprobante emitido por el proveedor.</b></p>
            </div>
        </footer>
    </body>
</html><?php /**PATH F:\project_warehouse\carden-web\sisventas74\resources\views/pdf/ingreso.blade.php ENDPATH**/ ?>